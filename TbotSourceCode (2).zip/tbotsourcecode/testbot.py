import base64
import os
import random as rng
import urllib.parse
from pathlib import Path

import discord
from discord import app_commands
from discord.ext import commands


def _read_token_from_file(path: Path) -> str:
    """Read a token from a file, decoding it if it is stored in base64."""
    raw_value = path.read_text(encoding="utf-8").strip()
    if not raw_value:
        raise RuntimeError(f"Token file is empty: {path}")

    try:
        return base64.b64decode(raw_value.encode("utf-8")).decode("utf-8")
    except Exception:
        return raw_value


def get_token() -> str:
    """Load the Discord token from the environment or a hidden user-level file."""
    env_token = os.getenv("DISCORD_TOKEN") or os.getenv("BOT_TOKEN")
    if env_token and env_token.strip():
        return env_token.strip()

    hidden_token_file = Path.home() / ".discord_bot_token"
    if hidden_token_file.exists():
        return _read_token_from_file(hidden_token_file)

    legacy_token_file = Path(__file__).with_name("dtkn.txt")
    if legacy_token_file.exists():
        return _read_token_from_file(legacy_token_file)

    raise RuntimeError(
        "No Discord token found. Set DISCORD_TOKEN or place the token in ~/.discord_bot_token."
    )


TOKEN = get_token()

# Create the bot with the default Discord intents.
intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)


def build_target_url(raw_query: str, search_type: str) -> str:
    """Build a Google search URL based on the user's query and selected search type."""
    query = raw_query.strip()

    # If the user enters nothing, send them to Google directly.
    if not query:
        return "https://google.com"

    # If the input looks like a simple website name, make it a domain URL.
    if " " not in query and not query.startswith(("http://", "https://", "www.")):
        return f"https://{query}.com"

    safe_query = urllib.parse.quote(query)

    # Create the appropriate Google search URL.
    if search_type == "images":
        return f"https://www.google.com/search?q={safe_query}&tbm=isch"
    if search_type == "news":
        return f"https://www.google.com/search?q={safe_query}&tbm=nws"
    if search_type == "videos":
        return f"https://www.google.com/search?q={safe_query}&tbm=vid"

    return f"https://www.google.com/search?q={safe_query}"


class GoogleLinkView(discord.ui.View):
    """A simple button that opens the generated search result URL."""

    def __init__(self, target_url: str):
        super().__init__()
        self.add_item(
            discord.ui.Button(
                label="Open Result",
                style=discord.ButtonStyle.link,
                emoji="🔍",
                url=target_url,
            )
        )


class GoogleSearchDropdown(discord.ui.Select):
    """A dropdown menu that lets the user choose how to search."""

    def __init__(self, raw_query: str):
        self.raw_query = raw_query

        options = [
            discord.SelectOption(label="General Search", description="Search everywhere on Google", emoji="🌐", value="general"),
            discord.SelectOption(label="Images", description="Search for images on Google", emoji="🖼️", value="images"),
            discord.SelectOption(label="News", description="Search for news articles", emoji="📰", value="news"),
            discord.SelectOption(label="Videos", description="Search for videos on Google", emoji="🎥", value="videos"),
        ]

        super().__init__(placeholder="How do you want to search?", min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):
        # Build the final URL using the user's search text and dropdown choice.
        url = build_target_url(self.raw_query, self.values[0])

        await interaction.response.edit_message(
            content=f"Results for: **{self.raw_query}** ({self.values[0].capitalize()})",
            view=GoogleLinkView(target_url=url),
        )


class DropdownView(discord.ui.View):
    """Container view that holds the Google search dropdown."""

    def __init__(self, raw_query: str):
        super().__init__()
        self.add_item(GoogleSearchDropdown(raw_query=raw_query))


@bot.event
async def on_ready():
    """Run when the bot finishes logging in."""
    print(f"Logged in as {bot.user}")

    try:
        # Sync slash commands with Discord so they appear for users.
        synced = await bot.tree.sync()
        print(f"Successfully synced {len(synced)} command(s).")
    except Exception as error:
        print(f"Error syncing commands: {error}")


@bot.tree.command(name="ping", description="Replies with Pong!")
async def ping(interaction: discord.Interaction):
    """Simple health check command."""
    await interaction.response.send_message("Pong!")


@bot.tree.command(name="anounce", description="Repeats what you type")
@app_commands.describe(anouncement="What should the bot say?")
async def anounce(interaction: discord.Interaction, anouncement: str):
    """Repeat a user-provided message back to them."""
    await interaction.response.send_message(f"Announcement: {anouncement}")


@bot.tree.command(name="rps", description="Paper, Rock, Scissors, Shoot!")
@app_commands.describe(what_do_you_choose="What do you choose?")
async def rps(interaction: discord.Interaction, what_do_you_choose: str):
    """Play a quick rock-paper-scissors game against the bot."""
    rng_choice = rng.choice(["Rock", "Paper", "Scissors"])
    await interaction.response.send_message(f"Bot chooses: {rng_choice}")

    if what_do_you_choose.lower() == "rock" and rng_choice == "Scissors":
        await interaction.followup.send("You win!")
    elif what_do_you_choose.lower() == "paper" and rng_choice == "Rock":
        await interaction.followup.send("You win!")
    elif what_do_you_choose.lower() == "scissors" and rng_choice == "Paper":
        await interaction.followup.send("You win!")
    elif what_do_you_choose.lower() == rng_choice.lower():
        await interaction.followup.send("It's a tie!")
    else:
        await interaction.followup.send("You lose!")


@bot.tree.command(name="bet", description="Roll a dice and see if you win!")
@app_commands.describe(pick_a_number="Pick a number between 1 and 6")
async def bet(interaction: discord.Interaction, pick_a_number: int):
    """Roll a dice and compare it to the user's guess."""
    rng_choice = rng.randint(1, 6)
    await interaction.response.send_message(f"Bot rolls: {rng_choice}")

    if pick_a_number == rng_choice:
        await interaction.followup.send("You win!")
    else:
        await interaction.followup.send("You lose!")


@bot.tree.command(name="google", description="Search something on Google")
@app_commands.describe(busqueda="What do you want to search for?")
async def google_search(interaction: discord.Interaction, busqueda: str):
    """Start a Google search flow using an interactive dropdown."""
    await interaction.response.send_message(
        content=f"You have searched for: **{busqueda}**. How do you want to search?",
        view=DropdownView(raw_query=busqueda),
        ephemeral=True,
    )


# Start the bot using the resolved token.
if __name__ == "__main__":
    bot.run(TOKEN)
